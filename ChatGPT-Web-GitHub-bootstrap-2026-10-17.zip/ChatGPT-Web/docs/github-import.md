# GitHub private repository handoff

Current state (2026-10-17): connected GitHub account `liuzhide666` has no ChatGPT-Web repository. The GitHub connector can write to existing repositories but cannot create one. This is a **prepared local Git worktree**, not an uploaded GitHub repository.

## One manual action needed on GitHub

1. Sign in at <https://github.com/new> as `liuzhide666`.
2. Repository name: **ChatGPT-Web**; visibility: **Private**.
3. Initialize with a README (this ensures an initial default-branch commit for the connector). Do not add an external license by default, because project dependency/redistribution rights still need review.
4. Create repository, and return its canonical URL for connector-based import. Do not paste tokens, passwords, keystore files or cookies.

## Import choices

- Preferred: use connected GitHub tools on the newly created repository. Commit prepared source tree to a `bootstrap/...` branch if the remote tool supports it, review then merge with checks.
- Offline/git alternative: unzip this package, run `git init -b main`, add/commit, set `origin`, and merge or push to the remote after reconciling the initial README. **Never force-push over an existing branch.**

After import verify private visibility, tracked source hashes, source-checks workflow run, GitHub Issues backlog, branch protection/rulesets, and no secret materials. The release binaries stay in the Library.

## Role of deliverables

- This ZIP: importable code/docs/test tree (no `.git`, no signed release APK).
- Optional `.bundle`: local Git commit snapshot for fidelity, not a GitHub remote publication.
- Original 1.1.0 source archive and release volumed-7z in Library: immutable provenance and rollback, not replaced by this package.
