ChatGPT-Web project: ALL FILES FLAT ZIP
Created: 2026-10-17

This ZIP has NO directories and NO entry names containing / or \.
Source files from the previous GitHub bootstrap ZIP: 238.
Extra: Git initialization bundle.
All file names are unique (four-digit index + original basename).

FILE-MAP.csv maps each flat filename back to the original repository path.
SHA256SUMS.txt validates each stored file.
restore_flat.py can rebuild the original directory layout when needed for Gradle, Python tests or GitHub.
The ZIP itself has no nested folders. To restore on your own machine, run:
    python restore_flat.py /path/to/this-zip /path/to/output-folder

Original signed APK and .7z release volumes are NOT in the previous GitHub bootstrap sources;
they remain in the Library formal release folder, separate from this GitHub repository export.
Signing secrets/passwords are excluded from this package.
