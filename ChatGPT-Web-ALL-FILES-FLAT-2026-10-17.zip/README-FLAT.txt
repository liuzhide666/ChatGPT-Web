ChatGPT-Web G1 Android CI engineering source snapshot (2026-10-17)
This ZIP contains ONLY root-level files. There are no directory entries and NO file paths in ZIP names.
Build baseline: Android 1.1.0 / versionCode 113, GeckoView 153.0.20260810162159.
GitHub PR #12 (portable Android CI) after GitHub JDK17/API37/Gradle 9.3.1 compile success.
This source snapshot is NOT a signed APK and does not certify HarmonyOS 7.
Original signed 1.1.0 APK, signing keys and multi-volume archives remain outside this delivery in the Library.
The old ChatGPT-Web-ALL-FILES-FLAT-2026-10-17.zip is a separate older GitHub-root snapshot; it is omitted here to prevent nested archives.
Use FILE-MAP.csv and restore_flat.py to reconstruct the original project directory layout.
Usage: python restore_flat.py <this.zip> <output_dir>
