#!/usr/bin/env python3
"""Restore the project source from a flat ZIP and verify each file hash."""
from pathlib import Path, PurePosixPath
from zipfile import ZipFile
import hashlib,csv,io,os,sys

def main():
    if len(sys.argv)!=3: raise SystemExit("Usage: python restore_flat.py SOURCE.zip OUTPUT_DIR")
    archive=Path(sys.argv[1]); root=Path(sys.argv[2]).resolve();root.mkdir(parents=True,exist_ok=True)
    with ZipFile(archive) as z:
        entries=list(csv.DictReader(io.StringIO(z.read('FILE-MAP.csv').decode('utf-8'))))
        for item in entries:
            path=item['original_path']; parts=PurePosixPath(path).parts
            if path.startswith('/') or '..' in parts or not parts or '\\' in path: raise ValueError(path)
            dest=root.joinpath(*parts)
            if not dest.resolve().is_relative_to(root): raise ValueError('Escaping archive target: '+path)
            raw=z.read(item['flat_name'])
            if len(raw)!=int(item['size_bytes']) or hashlib.sha256(raw).hexdigest()!=item['sha256']: raise ValueError('Hash/size mismatch: '+path)
            dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
            if item['git_mode']=='100755':dest.chmod(0o755)
    print('RESTORE_OK count='+str(len(entries)))
if __name__=='__main__': main()
