#!/usr/bin/env python3
"""Restore original GitHub bootstrap tree from a flat archive."""
import csv, hashlib, io, pathlib, sys, zipfile

def main():
    if len(sys.argv)!=3:
        raise SystemExit('usage: python restore_flat.py FLAT.zip OUTPUT_DIR')
    archive=pathlib.Path(sys.argv[1]); dest=pathlib.Path(sys.argv[2]); dest.mkdir(parents=True,exist_ok=True)
    root=dest.resolve()
    with zipfile.ZipFile(archive) as z:
        rows=list(csv.DictReader(io.StringIO(z.read('FILE-MAP.csv').decode('utf-8'))))
        for row in rows:
            original=row['original_path']
            if original.startswith('['):
                output=root / row['flat_name']
            else:
                parts=pathlib.PurePosixPath(original).parts
                if not parts or any(p in ('..','.') for p in parts) or original.startswith('/') or '\\' in original:
                    raise ValueError('invalid output path: '+original)
                output=root.joinpath(*parts)
            if not output.resolve().is_relative_to(root):
                raise ValueError('path escapes output folder: '+original)
            data=z.read(row['flat_name'])
            if len(data)!=int(row['size_bytes']) or hashlib.sha256(data).hexdigest()!=row['sha256']:
                raise ValueError('file hash/length mismatch: '+row['flat_name'])
            output.parent.mkdir(parents=True,exist_ok=True)
            output.write_bytes(data)
    print('Restored',len(rows),'files into',root)
if __name__=='__main__': main()
